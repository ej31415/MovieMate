package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    Button searchButton;
    Button goBackButton;
    TextView titleText;
    EditText search;
    EditText startDate;
    EditText endDate;
    EditText startTime;
    EditText endTime;
    CheckBox cheapest;
    TextView movieNameTitle;
    TextView movieName;
    TextView moviePriceTitle;
    TextView moviePrice;
    TextView movieTimeTitle;
    TextView movieTime;
    TextView searchTitle;
    TextView startDateTitle;
    TextView endDateTitle;
    TextView startTimeTitle;
    TextView endTimeTitle;

    ArrayList<String> list = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchButton = findViewById(R.id.searchButton);
        goBackButton = findViewById(R.id.goBackButton);
        titleText = findViewById(R.id.titleText);
        search = findViewById(R.id.search);
        startDate = findViewById(R.id.startDate);
        endDate = findViewById(R.id.endDate);
        startTime = findViewById(R.id.startTime);
        endTime = findViewById(R.id.endTime);
        cheapest = findViewById(R.id.cheapest);
        movieNameTitle = findViewById(R.id.movieNameTitle);
        movieName = findViewById(R.id.movieName);
        moviePriceTitle = findViewById(R.id.moviePriceTitle);
        moviePrice = findViewById(R.id.moviePrice);
        movieTimeTitle = findViewById(R.id.movieTimeTitle);
        movieTime = findViewById(R.id.movieTime);
        searchTitle = findViewById(R.id.searchTitle);
        startDateTitle = findViewById(R.id.startDateTitle);
        endDateTitle = findViewById(R.id.endDateTitle);
        startTimeTitle = findViewById(R.id.startTimeTitle);
        endTimeTitle = findViewById(R.id.endTimeTitle);

        goBackButton.setVisibility(View.INVISIBLE);
        movieNameTitle.setVisibility(View.INVISIBLE);
        movieName.setVisibility(View.INVISIBLE);
        moviePriceTitle.setVisibility(View.INVISIBLE);
        moviePrice.setVisibility(View.INVISIBLE);
        movieTimeTitle.setVisibility(View.INVISIBLE);
        movieTime.setVisibility(View.INVISIBLE);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    list.add(snapshot.getValue().toString());
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

        View.OnClickListener searchButtonListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MovieFunctions movieFunctions = new MovieFunctions();
                movieFunctions.deconstruct(list);

                String movie = search.getText().toString();
                boolean check = cheapest.isChecked();
                String startDay = startDate.getText().toString();
                String endDay = endDate.getText().toString();
                String startTiming = startTime.getText().toString();
                String endTiming = endTime.getText().toString();

                goBackButton.setVisibility(View.VISIBLE);
                movieNameTitle.setVisibility(View.VISIBLE);
                movieName.setVisibility(View.VISIBLE);
                moviePriceTitle.setVisibility(View.VISIBLE);
                moviePrice.setVisibility(View.VISIBLE);
                movieTimeTitle.setVisibility(View.VISIBLE);
                movieTime.setVisibility(View.VISIBLE);

                searchButton.setVisibility(View.INVISIBLE);
                search.setVisibility(View.INVISIBLE);
                cheapest.setVisibility(View.INVISIBLE);
                startDate.setVisibility(View.INVISIBLE);
                endDate.setVisibility(View.INVISIBLE);
                startTime.setVisibility(View.INVISIBLE);
                endTime.setVisibility(View.INVISIBLE);
                searchTitle.setVisibility(View.INVISIBLE);
                startDateTitle.setVisibility(View.INVISIBLE);
                endDateTitle.setVisibility(View.INVISIBLE);
                startTimeTitle.setVisibility(View.INVISIBLE);
                endTimeTitle.setVisibility(View.INVISIBLE);

                if (!movie.equals("") && !check && startDay.equals("") && startTiming.equals("") && endDay.equals("") && endTiming.equals("")) {
                    movieName.setText(movieFunctions.movies.get(movieFunctions.getMoviesFromString(movie)));
                    moviePrice.setText(movieFunctions.prices.get(movieFunctions.getMoviesFromString(movie)).toString()+"0");
                    movieTime.setText(movieFunctions.showTimes.get(movieFunctions.getMoviesFromString(movie)).toString());
                }

                else if (!movie.equals("") && check && startDay.equals("") && startTiming.equals("") && endDay.equals("") && endTiming.equals("")) {
                    movieName.setText(movieFunctions.movies.get(movieFunctions.findCheapestMovie(movie)));
                    moviePrice.setText(movieFunctions.prices.get(movieFunctions.findCheapestMovie(movie)).toString()+"0");
                    movieTime.setText(movieFunctions.showTimes.get(movieFunctions.findCheapestMovie(movie)).toString());
                }

                else if (movie.equals("") && check && startDay.equals("") && startTiming.equals("") && endDay.equals("") && endTiming.equals("")) {
                    movieName.setText(movieFunctions.movies.get(movieFunctions.findCheapestMovie()));
                    moviePrice.setText(movieFunctions.prices.get(movieFunctions.findCheapestMovie()).toString()+"0");
                    movieTime.setText(movieFunctions.showTimes.get(movieFunctions.findCheapestMovie()).toString());
                }

                else if (movie.equals("") && !startDay.equals("") && !startTiming.equals("") && !endDay.equals("") && !endTiming.equals("")) {
                    Time startT = new Time(startDay + "/" + startTiming);
                    Time endT = new Time(endDay + "/" + endTiming);
                    movieName.setText(movieFunctions.movies.get(movieFunctions.findCheapestMovie(startT, endT)));
                    moviePrice.setText(movieFunctions.prices.get(movieFunctions.findCheapestMovie(startT, endT)).toString()+"0");
                    movieTime.setText(movieFunctions.showTimes.get(movieFunctions.findCheapestMovie(startT, endT)).toString());
                }

                else if (!movie.equals("") && !startDay.equals("") && !startTiming.equals("") && !endDay.equals("") && !endTiming.equals("")) {
                    Time startT = new Time(startDay + "/" + startTiming);
                    Time endT = new Time(endDay + "/" + endTiming);
                    movieName.setText(movieFunctions.movies.get(movieFunctions.findCheapestMovie(movie, startT, endT)));
                    moviePrice.setText(movieFunctions.prices.get(movieFunctions.findCheapestMovie(movie, startT, endT)).toString()+"0");
                    movieTime.setText(movieFunctions.showTimes.get(movieFunctions.findCheapestMovie(movie, startT, endT)).toString());
                }

                else {
                    movieName.setText("None");
                    moviePrice.setText("None");
                    movieTime.setText("None");
                }
            }
        };
        searchButton.setOnClickListener(searchButtonListener);

        View.OnClickListener goBackButtonListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goBackButton.setVisibility(View.INVISIBLE);
                movieNameTitle.setVisibility(View.INVISIBLE);
                movieName.setVisibility(View.INVISIBLE);
                moviePriceTitle.setVisibility(View.INVISIBLE);
                moviePrice.setVisibility(View.INVISIBLE);
                movieTimeTitle.setVisibility(View.INVISIBLE);
                movieTime.setVisibility(View.INVISIBLE);

                searchButton.setVisibility(View.VISIBLE);
                search.setVisibility(View.VISIBLE);
                cheapest.setVisibility(View.VISIBLE);
                startDate.setVisibility(View.VISIBLE);
                endDate.setVisibility(View.VISIBLE);
                startTime.setVisibility(View.VISIBLE);
                endTime.setVisibility(View.VISIBLE);
                searchTitle.setVisibility(View.VISIBLE);
                startDateTitle.setVisibility(View.VISIBLE);
                endDateTitle.setVisibility(View.VISIBLE);
                startTimeTitle.setVisibility(View.VISIBLE);
                endTimeTitle.setVisibility(View.VISIBLE);
            }
        };
        goBackButton.setOnClickListener(goBackButtonListener);

    }
}